package com.cyj.s6;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cyj.animal.AnimalDTO;
import com.cyj.animal.AnimalService;
import com.cyj.util.Pager;

@Controller
@RequestMapping(value="/animal/**")
public class AnimalController {
	
	@Inject
	private AnimalService animalService;
	
	//list
	@RequestMapping(value="animalList")
	public ModelAndView list(Pager pager) throws Exception {
		ModelAndView mv = animalService.list(pager);
		return mv;
	}
	
	//select
	@RequestMapping(value="animalSelect")
	public ModelAndView select(int num) throws Exception {
		ModelAndView mv = animalService.select(num);
		return mv;
	}
	
	//write form
	
	
	
	//write process
	@RequestMapping(value="animalWrite", method=RequestMethod.POST)
	public ModelAndView write(AnimalDTO animalDTO, HttpSession session, List<MultipartFile> f1, RedirectAttributes rd) throws Exception {
		String realPath = session.getServletContext().getRealPath("resources/animal");
		System.out.println(realPath);
		ModelAndView mv = animalService.insert(animalDTO, f1, session);
		return mv;
	}
	
	//update form
	
	//update process
	
}
