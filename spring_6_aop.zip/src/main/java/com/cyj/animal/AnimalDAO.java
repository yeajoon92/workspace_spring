package com.cyj.animal;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.cyj.board.BoardDTO;
import com.cyj.util.Pager;

@Repository
public class AnimalDAO {
	
	@Inject
	private SqlSession sqlSession;
	private static final String NAMESPACE="animalMapper.";
	
	public int getNum() throws Exception {
		return sqlSession.selectOne(NAMESPACE+"getNum");
	}
	
	public List<AnimalDTO> list(Pager pager) throws Exception {
		return sqlSession.selectList(NAMESPACE+"list", pager);
	}

	public AnimalDTO select(int num) throws Exception {
		return sqlSession.selectOne(NAMESPACE+"select", num);
	}

	public int insert(AnimalDTO animalDTO) throws Exception {
		return sqlSession.insert(NAMESPACE+"insert", animalDTO);
	}

	public int update(AnimalDTO animalDTO) throws Exception {
		return sqlSession.update(NAMESPACE+"update", animalDTO);

	}

	public int delete(int num) throws Exception {
		return sqlSession.delete(NAMESPACE+"delete", num);
	}

	public int totalCount(Pager pager) throws Exception {
		return sqlSession.selectOne(NAMESPACE+"totalCount", pager);
	}
	
}
