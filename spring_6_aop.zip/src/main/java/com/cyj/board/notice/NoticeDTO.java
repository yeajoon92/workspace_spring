package com.cyj.board.notice;

import com.cyj.board.BoardDTO;

public class NoticeDTO extends BoardDTO {
	
}
