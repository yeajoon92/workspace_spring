package com.cyj.board.notice;

import java.util.Random;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cyj.file.FileDAO;
import com.cyj.file.FileDTO;

@Service
@Transactional //이 클래스 내의 모든 메서드는 transaction의 영향을 받겠다는 뜻
public class NoticeTestService {
	
	@Inject
	private NoticeDAO noticeDAO;
	@Inject
	private FileDAO fileDAO;
	
	@Transactional
	public void insert(NoticeDTO noticeDTO, FileDTO fileDTO) throws Exception {
		noticeDAO.insert(noticeDTO);
		
		
		fileDAO.insert(fileDTO);
	}
	
}
