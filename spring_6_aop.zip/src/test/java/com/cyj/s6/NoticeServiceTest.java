package com.cyj.s6;

import static org.junit.Assert.*;

import java.util.Random;

import javax.inject.Inject;

import org.junit.Test;

import com.cyj.board.notice.NoticeDTO;
import com.cyj.board.notice.NoticeTestService;
import com.cyj.file.FileDTO;

public class NoticeServiceTest extends AbstractTestCase {
	
	@Inject
	private NoticeTestService ns;
	
	@Test
	public void test() throws Exception {
		NoticeDTO noticeDTO = new NoticeDTO();
		FileDTO fileDTO = new FileDTO();
		Random r = new Random();
		int num = r.nextInt(2);
		
		noticeDTO.setNum(35); //DB 확인하고 중복되지 않는 번호로 넣기
		noticeDTO.setTitle("T");
		noticeDTO.setWriter("T");
		noticeDTO.setContents("T");
		if(num==0) {
			throw new Exception();
		}
		
		fileDTO.setNum(35); //DB 확인하고 중복되지 않는 번호로 넣기
		fileDTO.setFname(null);
		fileDTO.setOname("T");
		fileDTO.setKind("N");
		
		ns.insert(noticeDTO, fileDTO);
	}

}
