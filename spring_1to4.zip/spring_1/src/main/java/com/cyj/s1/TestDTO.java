package com.cyj.s1;

public class TestDTO {
	private String t;

	public String getT() {
		return t;
	}

	public void setT(String t) {
		this.t = t;
	}
	
	

}
