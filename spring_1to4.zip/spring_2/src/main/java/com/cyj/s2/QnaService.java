package com.cyj.s2;

import org.springframework.beans.factory.annotation.Autowired;

public class QnaService {
	
	@Autowired
	private QnaDAO qnaDAO;
	
	public void setQnaDAO(QnaDAO qnaDAO) { //setter or constructor
		this.qnaDAO = qnaDAO;
	}
	
	public void list() {
		System.out.println("QNA Service List");
		qnaDAO.list();
	}

}
