package com.cyj.s2;

public class QnaDAO {
	
	public void list() {
		System.out.println("QNA DAO LIST");
	}

}
