package com.cyj.notice;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

@Service
public class NoticeService {
	@Inject
	private NoticeDAO noticeDAO;
	
	public void list() {
		System.out.println("Notice Service");
		noticeDAO.list();
	}

}
