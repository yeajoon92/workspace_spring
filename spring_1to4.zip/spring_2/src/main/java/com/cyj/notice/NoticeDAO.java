package com.cyj.notice;

import org.springframework.stereotype.Repository;

@Repository
public class NoticeDAO {
	
	public void list() {
		System.out.println("Notice DAO");
	}

}
