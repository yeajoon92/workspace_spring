package com.cyj.file;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.web.multipart.MultipartFile;

import com.cyj.board.BoardDTO;

public class FileDAO {
	
	@Inject
	private SqlSession sqlSession;
	private static final String NAMESPACE = "fileMapper.";
	
	public List<FileDTO> list(FileDTO fileDTO) {
		return sqlSession.selectList(NAMESPACE+"list", num);
	}
	
	public FileDTO select(int fnum) {
		return sqlSession.selectOne(NAMESPACE+"select", fnum);
	}
	
	public int insert(FileDTO fileDTO) {
		return sqlSession.insert(NAMESPACE+"insert", fileDTO);
	}
	
	public int deleteAll(FileDTO fileDTO) {
		return sqlSession.delete(NAMESPACE+"deleteAll", fileDTO);
	}
	
	public int delete(int fnum) {
		return sqlSession.delete(NAMESPACE+"delete", fnum);
	}
	
}
