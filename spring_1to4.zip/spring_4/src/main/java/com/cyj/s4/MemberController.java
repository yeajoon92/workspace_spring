package com.cyj.s4;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cyj.board.member.MemberDTO;
import com.cyj.board.member.MemberService;

@Controller
@RequestMapping(value="/member/**")
public class MemberController {
	
	@Inject
	private MemberService memberService;
	
	//idCheck
	@RequestMapping(value="idCheck")
	public String idCheck(String id, Model model) throws Exception {
		MemberDTO memberDTO = memberService.idCheck(id);
		//int result=0	//사용 불가능
		//result=1		//사용 가능
		int result=0;
		if(memberDTO == null) {
			result=1;
		}
		
		model.addAttribute("result", result);
		return "common/result";
	}
	
	//join
	@RequestMapping(value="join", method=RequestMethod.GET)
	public void join() throws Exception {
		
	}
	
	//join process
	@RequestMapping(value="join", method=RequestMethod.POST)
	public String join(MemberDTO memberDTO, RedirectAttributes rd) throws Exception {
		memberDTO.setGrade(9);
		int result = memberService.join(memberDTO);
		String path="redirect:../";
		if(result<1) {
			path="redirect:./join";
			rd.addFlashAttribute("msg", "Join Fail");
		}
		return path;
	}
	
	//idCheck
	@RequestMapping(value="idCheck")
	public String idCheck() {
		return "member/idCheck";
	}
	
	//login
	@RequestMapping(value="login", method=RequestMethod.GET)
	public void login() throws Exception {
		
	}
	
	//login process
	@RequestMapping(value="login", method=RequestMethod.POST)
	public String login(MemberDTO memberDTO, HttpSession session /*HttpServletRequest request*/, RedirectAttributes rd) throws Exception {
		memberDTO = memberService.login(memberDTO);
		String path="";
		if(memberDTO != null) {
			/*HttpSession session = request.getSession();*/
			session.setAttribute("member", memberDTO);
			path="redirect:../";
		}else {
			path="redirect:./login";
			rd.addFlashAttribute("msg", "Login Fail");
		}
		return path;
	}
	
	//update
	@RequestMapping(value="update", method=RequestMethod.GET)
	public void update() throws Exception {
		
	}
	
	//update process
	@RequestMapping(value="update", method=RequestMethod.POST)
	public String update(MemberDTO memberDTO, HttpSession session, RedirectAttributes rd) throws Exception {
		MemberDTO sessionMemberDTO = (MemberDTO)session.getAttribute("member"); // change Object type into MemberDTO type
		memberDTO.setId(sessionMemberDTO.getId());
		int result = memberService.update(memberDTO);
		if(result>0) {
			memberDTO.setGrade(sessionMemberDTO.getGrade());
			session.setAttribute("member", memberDTO);
		}else {
			rd.addFlashAttribute("msg", "Update Fail");
		}
		return "redirect:./myPage";
	}
	
	//delete process
	@RequestMapping(value="delete")
	public String delete(HttpSession session, RedirectAttributes rd) throws Exception {
		MemberDTO memberDTO = (MemberDTO)session.getAttribute("member");
		int result = memberService.delete(memberDTO.getId());
		String message = "Delete Fail";
		if(result>0) {
			message = "Delete Success";
			session.invalidate();
		}
		rd.addFlashAttribute("msg", message);
		return "redirect:../";
	}
	
	//myPage
	@RequestMapping(value="myPage")
	public void myPage() throws Exception {
		
	}
	
	//logout process
	@RequestMapping(value="logout")
	public String logout(HttpSession session) throws Exception {
		session.invalidate();
		return "redirect:../";
	}
	
}
