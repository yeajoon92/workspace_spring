package com.cyj.s4;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cyj.board.BoardDTO;
import com.cyj.board.notice.NoticeDTO;
import com.cyj.board.notice.NoticeService;
import com.cyj.util.FileSaver;
import com.cyj.util.Pager;

@Controller
@RequestMapping(value="/notice/**") //다른 속성 없이 value만 있을 경우 value 생략 가능
public class NoticeController {
	
	@Inject
	private NoticeService noticeService;
	
	//list
	@RequestMapping(value="noticeList")
	public String list(Model model, Pager pager) throws Exception {
		List<BoardDTO> ar = noticeService.list(pager);
		model.addAttribute("board", "notice");
		model.addAttribute("list", ar);
		model.addAttribute("pager", pager);
		return "board/boardList";
	}
	
	//select
	@RequestMapping(value="noticeSelect")
	public String select(Model model, int num) throws Exception {
		BoardDTO boardDTO = noticeService.select(num);
		model.addAttribute("board", "notice");
		model.addAttribute("boardDTO", boardDTO);
		//System.out.println(boardDTO.getTitle());
		
		return "board/boardSelect";
	}
	
	//write form
	@RequestMapping(value="noticeWrite", method=RequestMethod.GET)
	public String write(Model model) {
		model.addAttribute("board", "notice");
		return "board/boardWrite";
	}
	
	//write process
	@RequestMapping(value="noticeWrite", method=RequestMethod.POST)
	public String write(BoardDTO boardDTO, HttpSession session, MultipartFile [] f1, RedirectAttributes rd) throws Exception {
		String realPath = session.getServletContext().getRealPath("resources/upload");
		System.out.println(realPath);
		
		/*FileSaver fs = new FileSaver(); // ? 왜 지운지 모름
		fs.saveFile3(realPath, f1);*/
		
		int result = noticeService.insert(boardDTO, f1, session);
		/*if(result<1) { //NoticeService에서 무조건 result=1을 반환하므로 이 코드 필요없음
			rd.addFlashAttribute("msg", "Insert Fail");
		}*/
		//System.out.println("write : " + boardDTO.getTitle());
		return "redirect:./noticeList";
	}
	
	//update form
	@RequestMapping(value="noticeUpdate", method=RequestMethod.GET)
	public String update(Model model) {
		model.addAttribute("board", "notice");
		return "board/boardUpdate";
	}
	
	//update process
	@RequestMapping(value="noticeUpdate", method=RequestMethod.POST)
	public void update(BoardDTO boardDTO) {
		System.out.println("update : " + boardDTO.getTitle());
	}
	
	//delete process
	@RequestMapping(value="noticeDelete", method=RequestMethod.POST)
	public void delete(int num) {
		System.out.println("delete : " + num);
	}

}
