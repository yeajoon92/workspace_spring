package com.cyj.board.notice;

import java.sql.Date;

import com.cyj.board.BoardDTO;

public class NoticeDTO extends BoardDTO {
		
}
