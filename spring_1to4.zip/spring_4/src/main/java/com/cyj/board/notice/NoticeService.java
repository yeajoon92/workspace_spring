package com.cyj.board.notice;

import java.io.File;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cyj.board.BoardDTO;
import com.cyj.board.BoardService;
import com.cyj.file.FileDAO;
import com.cyj.file.FileDTO;
import com.cyj.util.FileSaver;
import com.cyj.util.Pager;

@Service
public class NoticeService implements BoardService {
	@Inject
	private NoticeDAO noticeDAO;
	@Inject
	private FileDAO fileDAO;
	
	/*public NoticeService() { //used @Inject instead
		noticeDAO = new NoticeDAO();
	}*/
	
	public List<BoardDTO> list(Pager pager) throws Exception {
		pager.makeRow();
		int totalCount = noticeDAO.totalCount(pager);
		pager.makePage(totalCount);
		return noticeDAO.list(pager);
	}
	
	public BoardDTO select(int num) throws Exception {
		FileDTO fileDTO = new FileDTO();
		fileDTO.setNum(num);
		fileDTO.setKind("N");
		List<FileDTO> files = fileDAO.list(fileDTO);
		return noticeDAO.select(num);
	}
	
	public String select(int num, Model model, RedirectAttributes rd) throws Exception {
		FileDTO fileDTO = new FileDTO();
		fileDTO.setNum(num);
		fileDTO.setKind("N");
		List<FileDTO> files = fileDAO.list(fileDTO);
		BoardDTO boardDTO = noticeDAO.select(num);
		String path = "";
		if(boardDTO != null) {
			model.addAttribute("dto", boardDTO);
			model.addAttribute("files", files);
			path="board/boardSelect";
		}else {
			rd.addFlashAttribute("msg", "해당 글은 없습니다.");
			path="./noticeList";
		}
		return path;
	}
	
	public int insert(BoardDTO boardDTO, MultipartFile [] f1, HttpSession session) throws Exception {
		FileSaver fs = new FileSaver();
		String realPath = session.getServletContext().getRealPath("resource/notice");
		/*File file = new File(realPath); //realPath만 받아오면 돼서 지움
		if(!file.exists()) {
			file.mkdirs();
		}*/
		
		int num = noticeDAO.getNum();
		boardDTO.setNum(num);
		int result = noticeDAO.insert(boardDTO);
		
		if(result<1) {
			throw new Exception(); //강제로 Exception을 발생시킴 -> 아래 코드 다 안함
		}
		
		for(MultipartFile mFile: f1) {
			if(mFile.isEmpty()) {
				continue;
			}
			FileDTO fileDTO = new FileDTO();
			fileDTO.setOname(mFile.getOriginalFilename());
			fileDTO.setFname(fs.saveFile3(realPath, mFile));
			fileDTO.setKind("N");
			fileDTO.setNum(num);
			fileDAO.insert(fileDTO);
			if(result<1) {
				throw new Exception();
			}
		}
		return result; //Exception이 발생 안 하면 result 반환
		//무조건 result=1 반환
	}
	
	public int update(BoardDTO boardDTO) throws Exception {
		return noticeDAO.update(boardDTO);
	}
	
	public int delete(int num) throws Exception {
		return noticeDAO.delete(num);
	}
	
	
	/*public static void main(String[] args) { //??
		NoticeService noticeService = new NoticeService();
		noticeService.select(1);
	}
	
	//select
	public void select(int num) throws Exception {
		try {
			BoardDTO boardDTO = noticeDAO.select(num);
			System.out.println(boardDTO.getTitle());
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}*/
	
}
