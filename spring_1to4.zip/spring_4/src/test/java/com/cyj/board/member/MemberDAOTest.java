package com.cyj.board.member;

import static org.junit.Assert.*;

import javax.inject.Inject;

import org.junit.Test;

import com.cyj.board.member.MemberDAO;
import com.cyj.board.member.MemberDTO;
import com.cyj.s4.AbstractTestCase;

public class MemberDAOTest extends AbstractTestCase {
	
	@Inject
	private MemberDAO memberDAO;
	private MemberDTO memberDTO;
	
	@Test
	public void joinTest() {
		//int result = memberDAO.join(memberDTO);
		assertEquals(1, result);
	}

}
