package com.cyj.s3;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.qna.QnaDTO;

@Controller
@RequestMapping(value="/qna/**")
public class QnaController {
	private ModelAndView mv;
	
	public QnaController() {
		mv = new ModelAndView();
	}
	
	@RequestMapping(value="qnaList")
	public void qnaList(@RequestParam(value="curPage", defaultValue="1") int c, Model model) {
		//int curPage = Integer.parseInt(request.getParameter("curPage"));
		//request.setAttribute("name",value);
		List<QnaDTO> ar = new ArrayList<QnaDTO>();
		QnaDTO qnaDTO = new QnaDTO();
		qnaDTO.setTitle("title1");
		ar.add(qnaDTO);
		QnaDTO qnaDTO2 = new QnaDTO();
		qnaDTO2.setTitle("title2");
		ar.add(qnaDTO2);
		model.addAttribute("list", ar);
		System.out.println("curPage : "+c);
	}
	
	@RequestMapping(value="qnaSelect")
	public void qnaSelect(@RequestParam(required=false) Integer num, Model model) {
		//required=false means there are not any params required (only for reference type /ie.Integer, String..)
		QnaDTO qnaDTO = new QnaDTO();
		qnaDTO.setTitle("title3");
		String board="qna";
		model.addAttribute(qnaDTO).addAttribute("board", board);
		
	}
	
	@RequestMapping(value="qnaWrite")
	public void qnaWrite() {
		
	}
	
	@RequestMapping(value="qnaWrite", method=RequestMethod.POST)
	public String qnaWrite2(QnaDTO qnaDTO/*String title, String writer, String contents*/) {
		/*QnaDTO qnaDTO = new QnaDTO(); can use (QnaDTO qnaDTO) instead
		qnaDTO.setWriter(writer);
		qnaDTO.setTitle(title);
		qnaDTO.setContents(contents);*/
		System.out.println(qnaDTO.getWriter());
		System.out.println(qnaDTO.getTitle());
		System.out.println(qnaDTO.getContents());
		return "redirect:./qnaWrite";
	}
	
	@RequestMapping(value="qnaUpdate")
	public ModelAndView qnaUpdate() {
		QnaDTO qnaDTO = new QnaDTO();
		qnaDTO.setTitle("title4");
		qnaDTO.setContents("contents5");
		qnaDTO.setWriter("writer5");
		ModelAndView mv = new ModelAndView();
		mv.addObject(qnaDTO);
		mv.setViewName("qna/qnaUpdate");
		return mv;
	}
	
	@RequestMapping(value="qnaUpdate", method=RequestMethod.POST)
	public String qnaUpdate2() {
		System.out.println("Qna Update");
		return "qnaUpdate";
	}
	
	@RequestMapping(value="qnaDelete", method=RequestMethod.POST)
	public String qnaDelete() {
		System.out.println("Qna Delete");
		return "";
	}
	
}
