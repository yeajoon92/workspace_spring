package com.cyj.s3;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value="/notice/**")
public class NoticeController {
	
	@RequestMapping(value="noticeList", method= {RequestMethod.GET, RequestMethod.POST})
	public String list() {
		System.out.println("Notice List");
		return "";
	}
	
	@RequestMapping(value="noticeWrite", method=RequestMethod.GET)
	public ModelAndView write() {
		System.out.println("Notice Write");
		ModelAndView mv = new ModelAndView();
		mv.setViewName("notice/noticeWrite");
		return mv;
	}
	
	@RequestMapping(value="noticeWrite", method=RequestMethod.POST)
	public String write2() {
		System.out.println("Notice Write Insert");
		return "";
	}

}
