package com.cyj.board.qna;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.board.BoardDTO;
import com.cyj.file.FileDAO;
import com.cyj.util.Pager;

@Service
public class QnaService {
	
	@Inject
	private QnaDAO qnaDAO;
	@Inject
	private FileDAO fileDAO;
	
	public ModelAndView list(Pager pager) throws Exception {
		pager.makeRow();
		int totalCount = qnaDAO.totalCount(pager);
		pager.makePage(totalCount);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("board/boardList");
		mv.addObject("list", qnaDAO.list(pager));
		mv.addObject("pager", pager);
		return mv;
	}
	
	public ModelAndView select(int num) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		//1. qna table
		BoardDTO boardDTO = qnaDAO.select(num);
		
		//2. Files table
		if(boardDTO != null) {
			mv.setViewName("board/boardList");
			mv.addObject("dto", boardDTO);
		}else {
			mv.setViewName("redirect:./qnaList");
			mv.addObject("msg", "글이 없습니다");
		}
		mv.addObject("board", "qna");
		
		return mv;
	}
	
	public ModelAndView insert(BoardDTO boardDTO, List<MultipartFile> f1, HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
	public ModelAndView update(BoardDTO boardDTO, List<MultipartFile> f1, HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
	public ModelAndView delete(int num, HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
}
