package com.cyj.animal;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.file.FileDAO;
import com.cyj.file.FileDTO;
import com.cyj.util.FileSaver;
import com.cyj.util.Pager;

@Service
public class AnimalService {
	
	@Inject
	private AnimalDAO animalDAO;
	@Inject
	private FileDAO fileDAO;
	
	public ModelAndView list(Pager pager) throws Exception {
		pager.makeRow();
		int totalCount = animalDAO.totalCount(pager);
		pager.makePage(totalCount);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("animal/animalList");
		mv.addObject("list", animalDAO.list(pager));
		mv.addObject("pager", pager);
		return mv;
	}
	
	public ModelAndView select(int num) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		//1. Animal Table
		AnimalDTO animalDTO = animalDAO.select(num);
		
		//2. Files Table
		if(animalDTO != null) {
			mv.setViewName("animal/animalSelect");
			mv.addObject("dto", animalDTO);
		}else {
			mv.setViewName("redirect:./animalList");
			mv.addObject("msg", "글이 없습니다");
		}
		
		return mv;
	}
	
	public ModelAndView insert(AnimalDTO animalDTO, List<MultipartFile> f1, HttpSession session) throws Exception {
		//1. sequence num 가져오기
		int num = animalDAO.getNum();
		
		//2. Animal Table에 insert
		animalDTO.setNum(num);
		int result = animalDAO.insert(animalDTO);
		
		//transaction 처리
		if(result<1) {
			throw new Exception();
		}
		
		//3. HDD에 File Save
		FileSaver fs = new FileSaver();
		String realPath = session.getServletContext().getRealPath("resources/animal");
		
		for(MultipartFile multipartFile:f1) {
			if(multipartFile.isEmpty()) {
				continue;
			}
			String fname = fs.saveFile(realPath, multipartFile);
			
			//4. Files Table insert
			FileDTO fileDTO = new FileDTO();
			fileDTO.setNum(num);
			fileDTO.setFname(fname);
			fileDTO.setOname(multipartFile.getOriginalFilename());
			fileDTO.setKind("A");
			result = fileDAO.insert(fileDTO);
			//transaction
			if(result<1) {
				throw new Exception();
			}			
		}
		ModelAndView mv = new ModelAndView();
		mv.setViewName("redirect:./animalList");
		mv.addObject("msg", "Write Success");
		return mv;
	}
	
	public ModelAndView update(AnimalDTO animalDTO, List<MultipartFile> f1, HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		
		
		
		
		return mv;
	}
	
	public ModelAndView delete(int num, HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		
		
		
		
		return mv;
	}
	
}
