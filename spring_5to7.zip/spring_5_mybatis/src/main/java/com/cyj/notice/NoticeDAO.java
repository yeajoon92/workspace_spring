package com.cyj.notice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
@Repository
public class NoticeDAO {
	
	@Inject
	private SqlSession sqlSession;
	private String namespace="noticeMapper.";//mapper의 파일명
	
	public List<NoticeDTO> list(int startRow, int lastRow, String kind, String search) {
		Map<String, Object> map = new HashMap<String, Object>(); //보통 여기서 만들진 않음
		map.put("startRow", startRow);
		map.put("lastRow", lastRow);
		map.put("search", search);
		map.put("kind", kind);
		return sqlSession.selectList(namespace+"selectList", map);
	}
	
	public NoticeDTO selectOne(int num) {
		//글 하나 조회
		return sqlSession.selectOne(namespace+"selectOne", num);
	}
	
	public int delete(int num) {
		return sqlSession.delete(namespace+"del", num);
	}
	
	public int insert(NoticeDTO noticeDTO) {
		return sqlSession.insert(namespace+"ins", noticeDTO);
	}
}
