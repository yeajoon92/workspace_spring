package com.cyj.s5;

import static org.junit.Assert.*;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class ConnectionTest extends AbstractTestCase {
	
	
	@Inject
	private DriverManagerDataSource ds;
	
	@Test
	public void test() throws Exception {
		//assertNotNull(ds); //tester //ds가 null이면 객체가 안 만들어진거임
		assertNotNull(ds.getConnection()); //tester
	}
	
	
	/*@Inject
	private SqlSession sqlSession;
	
	@Test
	public void test() {
		assertNotNull(sqlSession);
	}*/

}
