package com.cyj.s5;

import static org.junit.Assert.*;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;

import com.cyj.notice.NoticeDAO;
import com.cyj.notice.NoticeDTO;

public class NoticeDAOTest extends AbstractTestCase{
	
	@Inject
	private NoticeDAO noticeDAO;
	
	@Test
	public void test() {
		//list
		List<NoticeDTO> ar = noticeDAO.list(1,10,"contents", "o");
		assertEquals(1, ar.size());
		
		//selectOne
		/*NoticeDTO noticeDTO = noticeDAO.selectOne(1);
		System.out.println(noticeDTO.getTitle());*/
		
		//delete
		/*int result = noticeDAO.delete(5);
		assertEquals(1, result);*/
		
		//insert
		/*NoticeDTO noticeDTO = new NoticeDTO();
		noticeDTO.setWriter("writer");
		noticeDTO.setTitle("title");
		noticeDTO.setContents("contents");
		int result = noticeDAO.insert(noticeDTO);
		assertEquals(1, result);*/
	}
	
}
