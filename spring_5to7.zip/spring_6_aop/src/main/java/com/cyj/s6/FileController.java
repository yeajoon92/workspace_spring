package com.cyj.s6;

import java.util.Enumeration;
import java.util.Iterator;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.file.FileDTO;
import com.cyj.file.FileService;
import com.cyj.file.PhotoDTO;

@Controller
@RequestMapping(value="/file/**")
public class FileController {
	
	@Inject
	private FileService fileService;
	
	@RequestMapping(value="fileDown")
	public ModelAndView fileDown(FileDTO fileDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.addObject("file", fileDTO);
		mv.setViewName("fileDown");
		return mv;
	}
	
	@RequestMapping(value="delete")
	public ModelAndView delete(int fnum) throws Exception {
		ModelAndView mv = fileService.delete(fnum);
		return mv;
	}
	
	@RequestMapping(value="photoUpload", method=RequestMethod.POST)
	public String se2(PhotoDTO photoDTO, HttpSession session) throws Exception {
		String result = fileService.se2(photoDTO, session);
		return result;
	}
	
	/*@RequestMapping(value="photoUpload", method=RequestMethod.POST)
	public void se2(String callback, String callback_func, MultipartFile Filedata) {
		System.out.println("callback : "+callback);
		System.out.println("callback_func : "+callback_func);
		System.out.println("Filedata: "+Filedata.getOriginalFilename());
	}*/
	
	/*@RequestMapping(value="photoUpload", method=RequestMethod.POST)
	public void se2(MultipartHttpServletRequest request) {
		Enumeration<Object> en= request.getParameterNames();
		while(en.hasMoreElements()) {
			String name = (String)en.nextElement(); //change Object type into String type
			System.out.println(name);
		}
		Iterator<String> names = request.getFileNames();
		
		while(names.hasNext()) {
			String n = names.next();
			System.out.println(n);
		}
	}*/
	
}
