package com.cyj.trans;

import org.springframework.stereotype.Component;

//Target
@Component
public class Transport {
	//Join points
	
	//point cut
	public void bus() {
		System.out.println("게임하기");
		System.out.println("잠자기");
	}
	
	public void subway() {
		System.out.println("노래듣기");
		System.out.println("옆사람 카톡 보기");
	}
	
}
