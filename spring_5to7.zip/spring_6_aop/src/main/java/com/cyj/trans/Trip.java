package com.cyj.trans;

import org.springframework.stereotype.Component;

@Component
public class Trip {
	
	public void go() {
		System.out.println("================");
		System.out.println("여행가기");
		System.out.println("================");
	}
	
}
