package com.cyj.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.servlet.view.AbstractView;

import com.cyj.file.FileDTO;

public class FileDown extends AbstractView {
	
	public FileDown() {
		setContentType("application/download;charset=UTF-8");
		
	}
	
	@Override
	protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		//model에 담아서 가져온 데이터 꺼내기
		FileDTO fileDTO = (FileDTO)model.get("file");
		String realPath = request.getSession().getServletContext().getRealPath("resources/notice");
		File file = new File(realPath, fileDTO.getFname());
		
		//한글 처리
		response.setCharacterEncoding(getContentType());
		
		//파일의 크리
		response.setContentLength((int)file.length);
		
		//실제 파일명(oname)을 UTF-8로 처리
		String fileName = URLEncoder.encode(fileDTO.getOname(), getContentType());
		
		response.setHeader("Content-Disposition", "attachment", "attachment", filename="\""+fileName*\**");
		response.setHeader("contente-Transfer-Encoding", "binary");
		
		OutputStream os = response.getOutputStream();
		FileInputStream fi = new FileInputStream(file);
		FileCopyUtils.copy(fi, os);
		
		fi.close();
		os.close();
		
	}
	
}
