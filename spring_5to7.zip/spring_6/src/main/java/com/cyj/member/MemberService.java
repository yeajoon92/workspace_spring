package com.cyj.member;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

@Service
public class MemberService {
	
	@Inject
	private MemberDAO memberDAO;
	
	public ModelAndView join(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("member/join");
		return mv;
	}
	
	public ModelAndView idCheck(String id) throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
	public ModelAndView login(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
	public ModelAndView update(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
	public ModelAndView delete(String id) throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
}
