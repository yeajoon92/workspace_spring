package com.cyj.s6;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.member.MemberDTO;
import com.cyj.member.MemberService;

@Controller
@RequestMapping(value="/member/**")
public class MemberController {
	
	@Inject
	private MemberService memberService;
	
	//join form
	@RequestMapping(value="join", method=RequestMethod.GET)
	public String join(Model model) throws Exception {
		model.addAttribute("board", "notice");
		return "member/join";
	}
	
	//idCheck
	@RequestMapping(value="idCheck")
	public ModelAndView idCheck(String id) throws Exception {
		ModelAndView mv = memberService.idCheck(id);
		return mv;
	}
	
	//join process
	@RequestMapping(value="join", method=RequestMethod.POST)
	public ModelAndView join(MemberDTO memberDTO, HttpSession session) throws Exception {
		ModelAndView mv = memberService.join(memberDTO);
		return mv;
	}
	
	//login form
	@RequestMapping(value="login", method=RequestMethod.GET)
	public ModelAndView login(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = memberService.login();
		return mv;
	}
	
	//login process
	@RequestMapping(value="login", method=RequestMethod.POST)
	public ModelAndView login(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = memberService.login(memberDTO);
		return mv;
	}
	
	//update form
	@RequestMapping(value="update", method=RequestMethod.GET)
	public ModelAndView update(String id) throws Exception {
		ModelAndView mv = memberService.
	}
	
	//update process
	@RequestMapping(value="update", method=RequestMethod.POST)
	public ModelAndView update(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = memberService.update(memberDTO);
		return mv;
	}
	
	//delete
	@RequestMapping(value="delete", method=RequestMethod.POST)
	public ModelAndView delete(String id) throws Exception {
		ModelAndView mv = memberService.delete(id);
		return mv;
	}
	
	//myPage
	
	//logOut
	
}
