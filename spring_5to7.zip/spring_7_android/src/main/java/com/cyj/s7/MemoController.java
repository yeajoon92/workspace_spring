package com.cyj.s7;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.memo.MemoService;

@Controller
@RequestMapping("/memo/**")
public class MemoController {
	
	@Inject
	private MemoService memoService;
	
	//list
	@RequestMapping(value="memoList")
	public ModelAndView list() throws Exception {
		ModelAndView mv = memoService.list();
		return mv;
	}
	
	//select
	@RequestMapping(value="memoSelect")
	public ModelAndView select(int num) throws Exception {
		ModelAndView mv = memoService.select(num);
		return mv;
	}
	
	//insert (Form)
	@RequestMapping(value="memoInsert", method=RequestMethod.GET)
	public String insert(Model model) throws Exception {
		return "memo/memoInsert";
	}
	
	//insert (process)
	@RequestMapping(value="memoInsert", method=RequestMethod.POST)
	public ModelAndView insert() throws Exception {
		ModelAndView mv = memoService.insert();
		return mv;
	}
	
	//update (Form)
	@RequestMapping(value="memoUpdate", method=RequestMethod.GET)
	public ModelAndView update(int num) throws Exception {
		ModelAndView mv = memoService.select(num);
		mv.setViewName("memo/memoUpdate");
		return mv;
	}
	
	//update (process)
	@RequestMapping(value="memoUpdate", method=RequestMethod.POST)
	public ModelAndView update() throws Exception {
		ModelAndView mv = memoService.update();
		return mv;
	}
	
	//delete
	@RequestMapping(value="memoDelete")
	public ModelAndView delete() throws Exception {
		ModelAndView mv = memoService.delete();
		return mv;
	}
	
}
