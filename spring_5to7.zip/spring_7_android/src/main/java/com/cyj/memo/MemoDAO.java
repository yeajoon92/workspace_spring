package com.cyj.memo;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class MemoDAO {
	
	@Inject
	private SqlSession sqlSession;
	private static final String NAMESPACE="memoMapper.";
	
	//list
	public List<MemoDTO> list() throws Exception {
		return sqlSession.selectList(NAMESPACE+"list");
	}
	
	//select
	
	//insert
	
	//update
	
	//delete
	
}
