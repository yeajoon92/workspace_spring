package com.cyj.memo;

public class MemoDTO {

}
