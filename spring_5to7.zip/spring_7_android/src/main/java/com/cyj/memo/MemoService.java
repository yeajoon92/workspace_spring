package com.cyj.memo;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

@Service
public class MemoService {
	
	@Inject
	private MemoDAO memoDAO;
	
	//list
	public ModelAndView list() throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
	//select
	public ModelAndView select(int num) throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
	//insert
	public ModelAndView insert() throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
	//update
	public ModelAndView update() throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
	//delete
	public ModelAndView delete() throws Exception {
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
}
